/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

public import BasicResults.Matrix.QuadraticForm
public import Discretization.GeneralGram

/-!
# The discretization inequality

The discretization theorem is a statement about matrices.  This file translates it into the
statement about functions that motivates it.  For a function `f` in the span of the first
family, the integral `∫ |f|² dμ` is bounded by a weighted sum of `|f(xᵢ)|²`.  For a function
`g` in the span of the second family, the weighted sum is bounded by the squared coefficient
norm.

The dictionary is elementary.  A coefficient vector `c` gives the function
`f(x) = ⟪c, a(x)⟫ = ∑ conj (cₖ) aₖ(x)`, and

* `∑ wᵢ |f(xᵢ)|² = c* G c` for the accumulated matrix `G = ∑ wᵢ a(xᵢ) a(xᵢ)*`
  (`Discretization.re_dotProduct_sum_mulVec`),
* `c* A c ≤ c* B c` whenever `A ≤ B` in the Loewner order
  (`Discretization.re_quadForm_le_of_le`),

both from `BasicResults.Matrix.QuadraticForm`, together with the one fact of this kind that does
involve the measure, `∫ |f|² dμ = c* (gram a μ) c`
(`Discretization.integral_norm_sq_combination`, proved below).

So a Loewner inequality between matrices is exactly an inequality between quadratic forms,
uniformly in the coefficient vector.  For the lower frame bound this reading is
`Discretization.mul_integral_norm_sq_le_sum`, which also serves the operator case and the
one-sided discretization.  The result is `Discretization.exists_discretization`.
-/

@[expose] public section

open Matrix MeasureTheory
open scoped ComplexOrder MatrixOrder

namespace Discretization

variable {ι κ Ω : Type*} [Fintype ι] [Fintype κ] [DecidableEq κ]
  [MeasurableSpace Ω] {μ : Measure Ω}

/-! ### The average and the coefficient norm -/

/-- The quadratic form of a multiple of the identity is the squared norm of the coefficient
vector. -/
theorem re_quadForm_smul_one [DecidableEq ι] (α : ℝ) (c : ι → ℂ) :
    RCLike.re (star c ⬝ᵥ ((α • (1 : Matrix ι ι ℂ)) *ᵥ c)) = α * ∑ k, ‖c k‖ ^ 2 := by
  rw [Matrix.smul_mulVec, Matrix.one_mulVec, dotProduct_smul, RCLike.smul_re]
  congr 1
  simp only [dotProduct, Pi.star_apply, map_sum, RCLike.star_def]
  exact Finset.sum_congr rfl fun k _ => by rw [RCLike.conj_mul]; norm_cast

/-- The average of `|f|²` for the function `f` with coefficient vector `c` is the quadratic
form of the Gram matrix. -/
theorem integral_norm_sq_combination {a : Ω → ι → ℂ}
    (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (c : ι → ℂ) :
    ∫ y, ‖star c ⬝ᵥ a y‖ ^ 2 ∂μ = RCLike.re (star c ⬝ᵥ ((gram a μ) *ᵥ c)) := by
  have h1 : ∀ y, ‖star c ⬝ᵥ a y‖ ^ 2
      = RCLike.re (star (a y) ⬝ᵥ ((vecMulVec c (star c)) *ᵥ a y)) := by
    intro y
    rw [re_dotProduct_vecMulVec_mulVec]
    have h2 : star (a y) ⬝ᵥ c = (starRingEnd ℂ) (star c ⬝ᵥ a y) := by
      simp only [dotProduct, Pi.star_apply, map_sum, map_mul, RCLike.star_def,
        Complex.conj_conj]
      exact Finset.sum_congr rfl fun k _ => by ring
    rw [h2, RCLike.norm_conj]
  rw [integral_congr_ae (Filter.Eventually.of_forall h1), integral_re_quadForm ha,
    Matrix.trace_mul_comm, Matrix.trace_mul_vecMulVec_self_star]

/-- **A positive definite Gram matrix makes the family linearly independent.**  If the Gram
matrix `I` of `a` is positive definite, then the function `f(y) = ⟪c, a(y)⟫` vanishes
everywhere only for `c = 0`: otherwise `∫ |f|² dμ = Re (c* I c)` would be zero
(`Discretization.integral_norm_sq_combination`), while it is positive for `c ≠ 0`. -/
theorem forall_eq_zero_of_posDef_gram {a : Ω → ι → ℂ} (ha : ∀ k, MemLp (fun x => a x k) 2 μ)
    (hI : (gram a μ).PosDef) (c : ι → ℂ) (hc : ∀ y, star c ⬝ᵥ a y = 0) : c = 0 := by
  by_contra hne
  have hpos := hI.re_dotProduct_pos hne
  rw [← integral_norm_sq_combination ha c] at hpos
  simp [hc] at hpos

/-- **A lower frame bound is a discretization inequality.**  If the weighted sum of the
rank-one matrices `a(xᵢ) a(xᵢ)*` dominates `α` times the Gram matrix of `a`, then every
function `f` in the span of `a`, with coefficient vector `c`, satisfies

`α · ∫ |f|² dμ ≤ ∑ wᵢ |f(xᵢ)|²`. -/
theorem mul_integral_norm_sq_le_sum {a : Ω → ι → ℂ} (ha : ∀ k, MemLp (fun x => a x k) 2 μ)
    {n : ℕ} {x : Fin n → Ω} {w : Fin n → ℝ} {α : ℝ}
    (h : α • gram a μ ≤ ∑ i, w i • vecMulVec (a (x i)) (star (a (x i)))) (c : ι → ℂ) :
    α * ∫ y, ‖star c ⬝ᵥ a y‖ ^ 2 ∂μ ≤ ∑ i, w i * ‖star c ⬝ᵥ a (x i)‖ ^ 2 := by
  calc α * ∫ y, ‖star c ⬝ᵥ a y‖ ^ 2 ∂μ
      = RCLike.re (star c ⬝ᵥ ((α • gram a μ) *ᵥ c)) := by
        rw [Matrix.smul_mulVec, dotProduct_smul, RCLike.smul_re,
          integral_norm_sq_combination ha c]
    _ ≤ RCLike.re (star c ⬝ᵥ ((∑ i, w i • vecMulVec (a (x i)) (star (a (x i)))) *ᵥ c)) :=
        re_quadForm_le_of_le h c
    _ = ∑ i, w i * ‖star c ⬝ᵥ a (x i)‖ ^ 2 := re_dotProduct_sum_mulVec x w c a

/-! ### The discretization inequality -/

variable [DecidableEq ι]

/-- **Discretization of the `L₂`-norm.**

Under the hypotheses of `Discretization.bss_generalized`, the `n` points and weights
discretize the norm of every function in the span of the first family from below,

`(1 - √((m-1)/n))² · ∫ |f|² dμ ≤ ∑ wᵢ |f(xᵢ)|²`,

and bound the weighted sum for every function in the span of the second family from above,

`∑ wᵢ |g(xᵢ)|² ≤ (1 + √((M-1)/n))² Λ · ‖c‖²`,

where `c` is the coefficient vector of `g`.

This is Corollary 4 of the paper, for finite families.  The hypothesis on the first family
is that its members are linearly independent in `L₂(μ)`, that is, that its Gram matrix `I`
is positive definite: the inequality involves only the functions of the span, and
`I^{-1/2} a` spans the same space with Gram matrix `1`.  If the second family is an
orthonormal basis of a reproducing kernel Hilbert space `H`, then the coefficient norm on the
right is the `H`-norm of `g`, and `Λ` bounds the squared norm of the embedding `H → L₂`. -/
theorem exists_discretization [Nonempty ι] [Nonempty κ]
    {J : Matrix κ κ ℂ} (hJ : J.PosDef) {Λ : ℝ} (hΛ : 0 < Λ)
    (hJΛ : J ≤ Λ • (1 : Matrix κ κ ℂ)) {a : Ω → ι → ℂ} {b : Ω → κ → ℂ}
    (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (hb : ∀ k, MemLp (fun x => b x k) 2 μ)
    (hI : (gram a μ).PosDef) (hgramb : gram b μ = J)
    {n : ℕ} (hmn : Fintype.card ι ≤ n) :
    ∃ (x : Fin n → Ω) (w : Fin n → ℝ), (∀ i, 0 < w i) ∧
      (∀ c : ι → ℂ, (1 - Real.sqrt ((Fintype.card ι - 1) / n)) ^ 2
            * ∫ y, ‖star c ⬝ᵥ a y‖ ^ 2 ∂μ
          ≤ ∑ i, w i * ‖star c ⬝ᵥ a (x i)‖ ^ 2) ∧
      (∀ c : κ → ℂ, ∑ i, w i * ‖star c ⬝ᵥ b (x i)‖ ^ 2
          ≤ (1 + Real.sqrt ((RCLike.re J.trace / Λ - 1) / n)) ^ 2 * Λ
              * ∑ k, ‖c k‖ ^ 2) := by
  obtain ⟨x, w, hwpos, hlow, hup⟩ := bss_generalized hJ hΛ hJΛ ha hb hI hgramb hmn
  refine ⟨x, w, hwpos, mul_integral_norm_sq_le_sum ha hlow, fun c => ?_⟩
  calc ∑ i, w i * ‖star c ⬝ᵥ b (x i)‖ ^ 2
      = RCLike.re (star c ⬝ᵥ
          ((∑ i, w i • vecMulVec (b (x i)) (star (b (x i)))) *ᵥ c)) :=
        (re_dotProduct_sum_mulVec x w c b).symm
    _ ≤ RCLike.re (star c ⬝ᵥ
          ((((1 + Real.sqrt ((RCLike.re J.trace / Λ - 1) / n)) ^ 2 * Λ)
            • (1 : Matrix κ κ ℂ)) *ᵥ c)) := re_quadForm_le_of_le hup c
    _ = (1 + Real.sqrt ((RCLike.re J.trace / Λ - 1) / n)) ^ 2 * Λ * ∑ k, ‖c k‖ ^ 2 :=
        re_quadForm_smul_one _ c

end Discretization
