/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

-- Brings `InnerProductSpace ℝ ℂ` into scope, so that the integral in `gram` elaborates with
-- the same `NormedSpace ℝ ℂ` instance as the restatements of `gram` in the Challenge modules
-- of `Palomar.BSS`, `Palomar.L2Discretization` and `Palomar.OneSidedDiscretization`, and the
-- bodies are the same term.
public import Mathlib.Analysis.InnerProductSpace.Basic
public import Mathlib.LinearAlgebra.Matrix.Hermitian
public import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
public import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure
public import Mathlib.MeasureTheory.Measure.Count

/-!
# From integrals of quadratic forms to Gram matrices

The link between the analytic side of the problem (functions on a measure space) and the
matrix algebra of `BasicResults/Matrix/` is a single identity.  For a finite family of
square-integrable functions, assembled into a vector-valued map `a : Ω → ι → ℂ`, and its
**Gram matrix**

`gram a μ k l = ∫ aₖ(x) · conj (aₗ(x)) dμ(x)`,

every matrix `Q` satisfies

`∫ a(x)* Q a(x) dμ(x) = Tr (Q · gram a μ)`.

Read from right to left, it says that a trace against the Gram matrix is an average, and an
average is attained somewhere.  That is how a good sampling point is found.

The file also records the two auxiliary facts that go with it: the integrand is integrable
(Cauchy–Schwarz for `L₂` functions, `MeasureTheory.MemLp.integrable_mul`), and if the
average of `g` is smaller than the average of `f`, then `g x < f x` at some point
(`Discretization.exists_lt_of_integral_lt`).  The paper phrases this as a set of positive
measure; one good point is all that is needed here.

For the counting measure on a finite set the Gram matrix is the sum of the rank-one matrices
of the points (`Discretization.gram_count`), which is how a statement over a measure space
specializes to finitely many vectors.
-/

@[expose] public section

open Matrix MeasureTheory

namespace Discretization

variable {ι Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} {a : Ω → ι → ℂ}

/-- The **Gram matrix** of a finite family of functions `a : Ω → ι → ℂ`, with entries
`∫ aₖ · conj aₗ dμ`.  In matrix notation this is `∫ a(x) a(x)* dμ(x)`. -/
noncomputable def gram (a : Ω → ι → ℂ) (μ : Measure Ω) : Matrix ι ι ℂ :=
  Matrix.of fun k l => ∫ x, a x k * star (a x l) ∂μ

/-- The entries of the Gram matrix, by definition. -/
@[simp]
theorem gram_apply (a : Ω → ι → ℂ) (μ : Measure Ω) (k l : ι) :
    gram a μ k l = ∫ x, a x k * star (a x l) ∂μ := rfl

/-- The Gram matrix is Hermitian: swapping the two indices conjugates the entry. -/
theorem isHermitian_gram (a : Ω → ι → ℂ) (μ : Measure Ω) : (gram a μ).IsHermitian := by
  ext k l
  rw [Matrix.conjTranspose_apply, gram_apply, gram_apply, RCLike.star_def, ← integral_conj]
  exact integral_congr_ae (Filter.Eventually.of_forall fun x => by simp [mul_comm])

/-- **The Gram matrix of the counting measure** on a finite set is the sum of the rank-one
matrices of the points, `∫ a a* d(count) = ∑_y a(y) a(y)*`. -/
theorem gram_count [Fintype Ω] [MeasurableSingletonClass Ω] (a : Ω → ι → ℂ) :
    gram a Measure.count = ∑ y, vecMulVec (a y) (star (a y)) := by
  ext k l
  rw [gram_apply, integral_fintype Integrable.of_finite, Matrix.sum_apply]
  simp [vecMulVec_apply]

/-- The product of two members of the family is integrable, by Cauchy–Schwarz for
`L₂`-functions. -/
theorem integrable_mul_star (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (k l : ι) :
    Integrable (fun x => a x k * star (a x l)) μ :=
  (ha k).integrable_mul (ha l).star

omit [MeasurableSpace Ω] in
/-- The squared modulus of a complex number, as the real part of `z * star z`. -/
theorem re_mul_star (z : ℂ) : RCLike.re (z * star z) = ‖z‖ ^ 2 := by
  rw [RCLike.star_def, RCLike.mul_conj]; norm_cast

/-- The squared modulus of a square-integrable function is integrable. -/
theorem integrable_norm_sq (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (p : ι) :
    Integrable (fun x => ‖a x p‖ ^ 2) μ := by
  rw [integrable_congr (Filter.Eventually.of_forall fun x => (re_mul_star (a x p)).symm)]
  exact (integrable_mul_star ha p p).re

/-- The average of `|aₚ|²` is the `p`-th diagonal entry of the Gram matrix. -/
theorem integral_norm_sq (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (p : ι) :
    ∫ x, ‖a x p‖ ^ 2 ∂μ = RCLike.re (gram a μ p p) := by
  rw [gram_apply, ← integral_re (integrable_mul_star ha p p),
    integral_congr_ae (Filter.Eventually.of_forall fun x => re_mul_star (a x p))]

variable [Fintype ι]

/-- The average of the squared euclidean norm of the family is the trace of its Gram
matrix. -/
theorem integral_sum_norm_sq (ha : ∀ k, MemLp (fun x => a x k) 2 μ) :
    ∫ x, ∑ p, ‖a x p‖ ^ 2 ∂μ = RCLike.re (gram a μ).trace := by
  rw [integral_finsetSum _ fun p _ => integrable_norm_sq ha p, Matrix.trace, map_sum]
  exact Finset.sum_congr rfl fun p _ => integral_norm_sq ha p

omit [MeasurableSpace Ω] in
/-- The quadratic form `a(x)* Q a(x)` written as a double sum. -/
theorem quadForm_eq_sum (Q : Matrix ι ι ℂ) (x : Ω) :
    star (a x) ⬝ᵥ (Q *ᵥ a x) = ∑ k, ∑ l, Q k l * (a x l * star (a x k)) := by
  simp only [dotProduct, Matrix.mulVec, Pi.star_apply, Finset.mul_sum]
  exact Finset.sum_congr rfl fun k _ => Finset.sum_congr rfl fun l _ => by ring

/-- The quadratic form of a fixed matrix along the family is integrable. -/
theorem integrable_quadForm (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (Q : Matrix ι ι ℂ) :
    Integrable (fun x => star (a x) ⬝ᵥ (Q *ᵥ a x)) μ := by
  have hint : ∀ k l, Integrable (fun x => Q k l * (a x l * star (a x k))) μ := fun k l =>
    (integrable_mul_star ha l k).const_mul _
  refine (integrable_congr (Filter.Eventually.of_forall fun x => quadForm_eq_sum Q x)).2 ?_
  exact integrable_finsetSum _ fun k _ => integrable_finsetSum _ fun l _ => hint k l

/-- **The average of a quadratic form is a trace against the Gram matrix:**
`∫ a(x)* Q a(x) dμ(x) = Tr (Q · gram a μ)`. -/
theorem integral_quadForm (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (Q : Matrix ι ι ℂ) :
    ∫ x, star (a x) ⬝ᵥ (Q *ᵥ a x) ∂μ = (Q * gram a μ).trace := by
  have hint : ∀ k l, Integrable (fun x => Q k l * (a x l * star (a x k))) μ := fun k l =>
    (integrable_mul_star ha l k).const_mul _
  calc ∫ x, star (a x) ⬝ᵥ (Q *ᵥ a x) ∂μ
      = ∫ x, ∑ k, ∑ l, Q k l * (a x l * star (a x k)) ∂μ :=
        integral_congr_ae (Filter.Eventually.of_forall fun x => quadForm_eq_sum Q x)
    _ = ∑ k, ∑ l, ∫ x, Q k l * (a x l * star (a x k)) ∂μ := by
        rw [integral_finsetSum _ fun k _ => integrable_finsetSum _ fun l _ => hint k l]
        exact Finset.sum_congr rfl fun k _ => integral_finsetSum _ fun l _ => hint k l
    _ = ∑ k, ∑ l, Q k l * gram a μ l k := by
        simp only [integral_const_mul, gram_apply]
    _ = (Q * gram a μ).trace := by
        simp [Matrix.trace, Matrix.diag, Matrix.mul_apply]

/-- The real-valued form of `Discretization.integral_quadForm`, which is what the verifiers
of the construction use. -/
theorem integral_re_quadForm (ha : ∀ k, MemLp (fun x => a x k) 2 μ) (Q : Matrix ι ι ℂ) :
    ∫ x, RCLike.re (star (a x) ⬝ᵥ (Q *ᵥ a x)) ∂μ = RCLike.re ((Q * gram a μ).trace) := by
  rw [← integral_quadForm ha Q, integral_re (integrable_quadForm ha Q)]

/-- **One good point suffices.**  If the average of `g` is strictly smaller than the average
of `f`, then `g x < f x` for at least one `x`.

This is the form in which the existence of an admissible sampling point is used.  The paper
states that the set of admissible points has positive measure; that is true but not needed.
The conclusion is strict, which is what makes the weight of the new point finite. -/
theorem exists_lt_of_integral_lt {f g : Ω → ℝ} (hf : Integrable f μ) (hg : Integrable g μ)
    (h : ∫ x, g x ∂μ < ∫ x, f x ∂μ) : ∃ x, g x < f x := by
  by_contra hcon
  simp only [not_exists, not_lt] at hcon
  exact absurd h (not_lt.2 (integral_mono hf hg fun x => hcon x))

/-- **One good point suffices when the two averages agree.**  For nonnegative `f` and `g`
whose averages satisfy `∫ g ≤ ∫ f`, there is a point with `g x ≤ f x` at which `f` is
moreover positive, provided the average of `f` is positive.

The positivity of `f x` is what the weight of the new point is built from, and the strict
inequality of `Discretization.exists_lt_of_integral_lt` is no longer available when the two
averages are equal.  The proof is the observation that `f ≤ g` everywhere would force
`f = g` almost everywhere, and then `f` to vanish almost everywhere. -/
theorem exists_le_of_integral_le {f g : Ω → ℝ} (hf : Integrable f μ) (hg : Integrable g μ)
    (hf0 : ∀ x, 0 ≤ f x) (hg0 : ∀ x, 0 ≤ g x) (hpos : 0 < ∫ x, f x ∂μ)
    (h : ∫ x, g x ∂μ ≤ ∫ x, f x ∂μ) : ∃ x, g x ≤ f x ∧ 0 < f x := by
  by_contra hcon
  simp only [not_exists, not_and, not_lt] at hcon
  -- at every point either `f` beats nothing, or it vanishes; in both cases `f x ≤ g x`
  have hle : ∀ x, f x ≤ g x := fun x => by
    by_cases hx : g x ≤ f x
    · have h0 := hcon x hx
      have h1 := hf0 x
      have h2 := hg0 x
      linarith
    · exact (not_le.mp hx).le
  -- so the two averages are equal, and `g - f` is a nonnegative function of average zero
  have hint : ∫ x, (g x - f x) ∂μ = 0 := by
    rw [integral_sub hg hf]
    have := integral_mono hf hg hle
    linarith
  have hae : (fun x => g x - f x) =ᵐ[μ] 0 :=
    (integral_eq_zero_iff_of_nonneg (fun x => sub_nonneg.2 (hle x)) (hg.sub hf)).1 hint
  -- where `f` and `g` agree, `f` vanishes, so the average of `f` is zero
  have hf_ae : ∀ᵐ x ∂μ, f x = 0 := by
    filter_upwards [hae] with x hx
    have hgf : g x ≤ f x := (sub_eq_zero.1 hx).le
    have := hcon x hgf
    have := hf0 x
    linarith
  rw [integral_eq_zero_of_ae hf_ae] at hpos
  exact absurd hpos (lt_irrefl 0)

end Discretization
