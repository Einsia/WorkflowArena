/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

public import BasicResults
public import Discretization.Parameters
public import Discretization.Potentials
public import Discretization.Barrier
public import Discretization.Averages
public import Discretization.UpperBarrier
public import Discretization.Iteration
public import Discretization.PotentialArgument
public import Discretization.EdgeCases.CardOne
public import Discretization.EdgeCases.SmallEffectiveDim
public import Discretization.EdgeCases.BothEdgeCases
public import Discretization.GeneralGram
public import Discretization.NormDiscretization
public import Discretization.BSS
public import Discretization.OneSidedDiscretization
public import Discretization.Infinite.NormDiscretization
public import Discretization.KieferWolfowitz.MixEstimate
public import Discretization.KieferWolfowitz.Design
public import Discretization.KieferWolfowitz.NonDegenerate
public import Discretization.KieferWolfowitz.DetMax
public import Discretization.KieferWolfowitz.MainTheorem
public import Discretization.KieferWolfowitz.Measure
public import Discretization.KieferWolfowitz.ConvexHull
public import Discretization.KieferWolfowitz.Compact
public import Discretization.KieferWolfowitz.JohnDecomposition
public import Discretization.KieferWolfowitz.PointCount
public import Discretization.UniformDiscretization
public import Discretization.LpDiscretization

/-!
# Norm discretization
-/
