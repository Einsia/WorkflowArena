# Task: Irrationality of ζ(3)

You are given a Lean 4 project in `/testbed` (toolchain `leanprover/lean4:v4.18.0`; dependencies pinned in `lake-manifest.json`
and fetched by `lake`, not vendored). Parts of the project that lead to the result below have been removed.

## Goal

In `Zeta3Irrational/Basic.lean`, replace the `sorry` with a complete proof of `zeta_3_irratoinal`:

```lean
theorem zeta_3_irratoinal : ¬ ∃ r : ℚ , r = riemannZeta 3
```

Keep the statement exactly as given (same name, binders, hypotheses and conclusion) and keep the file's existing
context (imports you need may be added).

## Rules

- You may add new Lean files anywhere in the project's source directories and import them where needed.
- Do not modify `lean-toolchain`, `lake-manifest.json`, the lakefile, or existing declarations in other files.
- No `sorry`, `admit`, new `axiom`, `unsafe`, `implemented_by`/`extern`, or kernel-check-skipping options.
  Only `propext`, `Quot.sound`, `Classical.choice` may appear in `#print axioms zeta_3_irratoinal`.
- Final grading rebuilds your files in a clean copy of this repository and checks the statement and axioms
  independently; self-reported results are not used.
- Mathematical reference: Beukers, A note on the irrationality of ζ(2) and ζ(3), Bull. LMS 11 (1979)

## Checks you may run

```sh
lake build
lake env lean Zeta3Irrational/Basic.lean
```
