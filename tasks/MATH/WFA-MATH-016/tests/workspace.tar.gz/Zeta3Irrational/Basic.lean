import Mathlib.Data.Int.Star
import Mathlib.NumberTheory.LSeries.HurwitzZetaValues
import Mathlib.Order.CompletePartialOrder
import Mathlib.RingTheory.DedekindDomain.Dvr
import PrimeNumberTheoremAnd.Consequences
import Mathlib.Analysis.RCLike.Basic
import Mathlib.Data.Real.StarOrdered
import Mathlib.Algebra.Lie.OfAssociative
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.Eval.SMul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.MeasureTheory.Integral.IntegrationByParts
import Zeta3Irrational.Integral
import Mathlib.Algebra.GCDMonoid.Finset
import Mathlib.Algebra.GCDMonoid.Nat
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Data.Nat.Choose.Factorization
import Mathlib.NumberTheory.PrimeCounting

open scoped Nat
open BigOperators Polynomial

theorem zeta_3_irratoinal : ¬ ∃ r : ℚ , r = riemannZeta 3 := by
  sorry

