/-
Copyright (c) 2026 Marcel Morgenstern. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Marcel Morgenstern
-/
import ErgodicTheory.Entropy.MargulisRuelleAbstract
import Mathlib.Analysis.SpecialFunctions.Log.PosLog

/-!
# Sharpening the Margulis–Ruelle reduction: the positive-part singular-value product
-/

open MeasureTheory Module

namespace ErgodicTheory.Entropy

/-! ## The positive-part singular-value product (part A) -/

section PosPart

variable {E F : Type*}
  [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
  [NormedAddCommGroup F] [InnerProductSpace ℝ F] [FiniteDimensional ℝ F]

/-- Documentation omitted. -/
theorem sum_posLog_singularValues_eq_log_prod_max_one (f : E →ₗ[ℝ] F) (s : Finset ℕ) :
    ∑ i ∈ s, Real.posLog (f.singularValues i)
      = Real.log (∏ i ∈ s, max 1 (f.singularValues i)) := by
  rw [Real.log_prod (fun i _ => by positivity)]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  exact Real.posLog_eq_log_max_one (f.singularValues_nonneg i)

end PosPart

/-- **The positive-part singular-value product (matrix / `toEuclideanLin` form).** The
specialization of `sum_posLog_singularValues_eq_log_prod_max_one` to the singular values of
`Matrix.toEuclideanLin M`, which is how the derivative cocycle accesses singular values
(`ErgodicTheory.sprod`, `ErgodicTheory/Lyapunov/OseledetsLimit/SingularValues.lean`). The sum of the
positive-part logarithms of the singular values of `M` equals the log of the positive-part
singular-value product `∏ i, max 1 σᵢ(M)`. -/
theorem sum_posLog_singularValues_toEuclideanLin_eq {d : ℕ} (M : Matrix (Fin d) (Fin d) ℝ)
    (s : Finset ℕ) :
    ∑ i ∈ s, Real.posLog ((Matrix.toEuclideanLin M).singularValues i)
      = Real.log (∏ i ∈ s, max 1 ((Matrix.toEuclideanLin M).singularValues i)) :=
  sum_posLog_singularValues_eq_log_prod_max_one (Matrix.toEuclideanLin M) s

end ErgodicTheory.Entropy
