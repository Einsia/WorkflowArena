/-
Copyright (c) 2026 Marcel Morgenstern. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Marcel Morgenstern
-/
import ErgodicTheory.TwoSided.Invertible
import ErgodicTheory.TwoSided.MeasurableInf
import Mathlib.Algebra.DirectSum.Module
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import ErgodicTheory.Ergodic.Kingman.Core
import ErgodicTheory.Ergodic.Birkhoff
import ErgodicTheory.Lyapunov.Extensions.DetIdentity
import ErgodicTheory.Lyapunov.MeasurableSubspace
import ErgodicTheory.Cocycle.FurstenbergKesten
import ErgodicTheory.Lyapunov.OseledetsLimit.Limit
import ErgodicTheory.Lyapunov.Forward
import ErgodicTheory.Lyapunov.ForwardV
import ErgodicTheory.Lyapunov.LimitEigenbasis
import ErgodicTheory.Lyapunov.FiltrationFromTopGapEnvelope
import ErgodicTheory.Lyapunov.TopGapEnvelope

/-!
# Oseledets splitting for invertible ergodic matrix cocycles
-/

open MeasureTheory Filter Topology Matrix DirectSum
open scoped Matrix.Norms.L2Operator RealInnerProductSpace

namespace ErgodicTheory

variable {X : Type*} [MeasurableSpace X] {d : ℕ}

section Flag

end Flag

section PerPoint

end PerPoint

section Pos

end Pos

/-- **The two-sided Oseledets multiplicative ergodic theorem (splitting form).**

For an *invertible* ergodic measure-preserving system `T : X ≃ᵐ X` and a measurable
everywhere-invertible cocycle generator `A` with `log⁺‖A‖, log⁺‖A⁻¹‖ ∈ L¹(μ)`, there are
`k` distinct Lyapunov exponents `λ₀ > ⋯ > λ_{k-1}` and a measurable, `A`-equivariant
**splitting** `ℝᵈ = E₀(x) ⊕ ⋯ ⊕ E_{k-1}(x)` of `EuclideanSpace ℝ (Fin d)` such that, for
`μ`-a.e. `x`, every nonzero `v ∈ Eᵢ(x)` grows forward at rate `λᵢ` and backward at rate
`−λᵢ`:
`(1/n) log‖A⁽ⁿ⁾(x) v‖ → λᵢ` and `(1/n) log‖(A⁽ⁿ⁾(T⁻ⁿx))⁻¹ v‖ → −λᵢ`. -/
theorem oseledets_splitting
    {μ : Measure X} [IsProbabilityMeasure μ] {T : X ≃ᵐ X}
    (hT : Ergodic T μ)
    (A : X → Matrix (Fin d) (Fin d) ℝ)
    (hA : ∀ x, (A x).det ≠ 0)
    (hAmeas : Measurable A)
    (hint : IntegrableLogNorm A μ)
    (hint' : IntegrableLogNorm (fun x => (A x)⁻¹) μ) :
    ∃ (k : ℕ) (lam : Fin k → ℝ)
      (E : Fin k → X → Submodule ℝ (EuclideanSpace ℝ (Fin d))),
      StrictAnti lam ∧
      (∀ i, MeasurableSubspace fun x => E i x) ∧
      ∀ᵐ x ∂μ,
        DirectSum.IsInternal (fun i => E i x) ∧
        (∀ i, E i x ≠ ⊥) ∧
        (∀ i, Submodule.map (Matrix.toEuclideanCLM (𝕜 := ℝ) (A x)).toLinearMap (E i x)
          = E i (T x)) ∧
        (∀ i, ∀ v ∈ E i x, v ≠ 0 →
          Tendsto
            (fun n : ℕ => (n : ℝ)⁻¹ *
              Real.log ‖Matrix.toEuclideanCLM (𝕜 := ℝ) (cocycle A T n x) v‖)
            atTop (𝓝 (lam i)) ∧
          Tendsto
            (fun n : ℕ => (n : ℝ)⁻¹ *
              Real.log ‖Matrix.toEuclideanCLM (𝕜 := ℝ)
                (cocycle A T n ((⇑T.symm)^[n] x))⁻¹ v‖)
            atTop (𝓝 (-lam i))) := by
  sorry

end ErgodicTheory
