/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

public import BasicResults.Auerbach
public import BasicResults.LittleGrothendieck
public import BasicResults.Spectral.MultiplicationOperator

/-!
# Basic results
-/
