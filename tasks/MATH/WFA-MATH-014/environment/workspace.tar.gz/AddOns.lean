/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

public import AddOns.Approximable
/-!
# Add-ons: compactness measured by s-numbers
-/
