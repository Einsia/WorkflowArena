module

public import Mathlib.SetTheory.Ordinal.Arithmetic
public import Mathlib.SetTheory.Cardinal.Aleph
public import Mathlib.SetTheory.Cardinal.Arithmetic

@[expose] public noncomputable section

universe u v

open Cardinal
open scoped InitialSeg

namespace Ordinal

def withBotOrderIso {α : Type u} [Preorder α] [IsWellOrder α (· < ·)] :
    ((· < ·) : WithBot α → WithBot α → Prop) ≃r
      Sum.Lex (emptyRelation (α := PUnit)) ((· < ·) : α → α → Prop) where
  toFun := WithBot.recBotCoe (Sum.inl PUnit.unit) Sum.inr
  invFun := Sum.elim (λ _ ↦ ⊥) (λ x ↦ x)
  left_inv x := by cases x <;> rfl
  right_inv x := by cases x <;> rfl
  map_rel_iff' {x y} := by cases x <;> cases y <;>
    simp only [Equiv.coe_fn_mk, WithBot.recBotCoe_bot, WithBot.recBotCoe_coe,
    WithBot.coe_lt_coe, WithBot.bot_lt_coe, empty_relation_apply, lt_self_iff_false, not_lt_bot,
    Sum.lex_inl_inl, Sum.lex_inr_inl, Sum.lex_inr_inr, Sum.Lex.sep]

@[simp]
theorem type_withBot {α : Type u} [Preorder α] [IsWellOrder α (· < ·)] :
    type ((· < ·) : WithBot α → WithBot α → Prop) = 1 + type ((· < ·) : α → α → Prop) := by
  change _ = type emptyRelation + _
  rw [← type_sum_lex, type_eq]
  exact ⟨withBotOrderIso⟩

theorem noMaxOrder_of_isSuccLimit {α : Type u} [Preorder α] [IsWellOrder α (· < ·)]
    (h : Order.IsSuccLimit (type ((· < ·) : α → α → Prop))) : NoMaxOrder α := by
  constructor
  intro a
  have := h.succ_lt_iff.mpr (typein_lt_type (· < ·) a)
  obtain ⟨b, hb⟩ := typein_surj (· < ·) this
  use b
  have := Order.lt_succ (typein ((· < ·) : α → α → Prop) a)
  rw [← hb, typein_lt_typein] at this
  exact this

theorem isSuccLimit_of_noMaxOrder {α : Type u} [Nonempty α] [Preorder α] [IsWellOrder α (· < ·)]
    (h : NoMaxOrder α) : Order.IsSuccLimit (type ((· < ·) : α → α → Prop)) := by
  constructor
  · simp only [isMin_iff_eq_bot, bot_eq_zero, type_eq_zero_iff_isEmpty, not_isEmpty_of_nonempty,
      not_false_eq_true]
  · intro o ho
    obtain ⟨x, hx⟩ := h.exists_gt (enum ((· < ·) : α → α → Prop) ⟨o, ho.1⟩)
    have := ho.2
    refine this ?_ (typein_lt_type ((· < ·) : α → α → Prop) x)
    rwa [← typein_lt_typein ((· < ·) : α → α → Prop), typein_enum] at hx

theorem isSuccLimit_iff_noMaxOrder {α : Type u} [Nonempty α] [Preorder α] [IsWellOrder α (· < ·)] :
    Order.IsSuccLimit (type ((· < ·) : α → α → Prop)) ↔ NoMaxOrder α :=
  ⟨noMaxOrder_of_isSuccLimit, isSuccLimit_of_noMaxOrder⟩

theorem type_Iio_lt {α : Type u} [LinearOrder α] [WellFoundedLT α] (x : α) :
    type (Subrel ((· < ·) : α → α → Prop) (Set.Iio x)) < type ((· < ·) : α → α → Prop) :=
  @typein_lt_type _ _ (inferInstanceAs (IsWellOrder α (· < ·))) x

def iicOrderIso {α : Type u} [LinearOrder α] [WellFoundedLT α] (x : α) :
    (Subrel ((· < ·) : α → α → Prop) (Set.Iic x)) ≃r
      Sum.Lex (Subrel ((· < ·) : α → α → Prop) (Set.Iio x)) (emptyRelation (α := PUnit)) where
  toFun y := if h : y = x then Sum.inr PUnit.unit else Sum.inl ⟨y, y.prop.lt_of_ne h⟩
  invFun := Sum.elim (λ y ↦ ⟨y, y.prop.le⟩) (λ _ ↦ ⟨x, le_rfl⟩)
  left_inv y := by aesop
  right_inv y := by
    obtain (y | y) := y
    · simp only [Sum.elim_inl, Subtype.coe_eta, dite_eq_ite, ite_eq_right_iff, reduceCtorEq,
        imp_false]
      exact y.prop.ne
    · simp only [Sum.elim_inr, ↓reduceDIte]
  map_rel_iff' {y z} := by
    simp only [Equiv.coe_fn_mk, subrel_val, Subtype.coe_lt_coe]
    split_ifs with h h' h'
    · rw [Sum.lex_inr_inr, empty_relation_apply, false_iff, not_lt,
        Subtype.coe_injective (h.trans h'.symm)]
    · simp only [Sum.lex_inr_inl, false_iff, not_lt, ← Subtype.coe_le_coe, h]
      exact z.prop
    · simp only [Sum.Lex.sep, true_iff]
      rw [← Subtype.coe_lt_coe]
      exact lt_of_le_of_ne (y.prop.trans_eq h'.symm) (h'.trans_ne (Ne.symm h)).symm
    · simp only [Sum.lex_inl_inl, subrel_val, Subtype.coe_lt_coe]

theorem type_Iic_eq {α : Type u} [LinearOrder α] [WellFoundedLT α] (x : α) :
    type (Subrel ((· < ·) : α → α → Prop) (Set.Iic x)) =
    type (Subrel ((· < ·) : α → α → Prop) (Set.Iio x)) + 1 := by
  change _ = _ + type emptyRelation
  rw [← type_sum_lex, type_eq]
  exact ⟨iicOrderIso x⟩

theorem type_Iic_lt {α : Type u} [LinearOrder α] [WellFoundedLT α] [NoMaxOrder α] (x : α) :
    type (Subrel ((· < ·) : α → α → Prop) (Set.Iic x)) < type ((· < ·) : α → α → Prop) := by
  rw [type_Iic_eq]
  haveI : Nonempty α := ⟨x⟩
  have h := isSuccLimit_of_noMaxOrder (inferInstanceAs (NoMaxOrder α))
  exact h.2.succ_lt (type_Iio_lt x)

/-!
## Lifting ordinals
-/

instance ULift.isTrichotomous {α : Type u} {r : α → α → Prop} [IsTrichotomous α r] :
    IsTrichotomous (ULift.{v} α) (InvImage r ULift.down) := by
  constructor
  rintro ⟨a⟩ ⟨b⟩
  simp only [ULift.up_inj, InvImage]
  exact IsTrichotomous.trichotomous a b

instance ULift.isTrans {α : Type u} {r : α → α → Prop} [IsTrans α r] :
    IsTrans (ULift.{v} α) (InvImage r ULift.down) := by
  constructor
  rintro ⟨a⟩ ⟨b⟩ ⟨c⟩
  simp only [InvImage]
  exact IsTrans.trans a b c

instance ULift.isWellOrder {α : Type u} {r : α → α → Prop} [IsWellOrder α r] :
    IsWellOrder (ULift.{v} α) (InvImage r ULift.down) :=
  ⟨⟩

theorem lift_typein_apply {α : Type u} {β : Type v} {r : α → α → Prop} {s : β → β → Prop}
    [IsWellOrder α r] [IsWellOrder β s]
    (f : r ≼i s) (a : α) :
    Ordinal.lift.{max u v, v} (Ordinal.typein s (f a)) =
    Ordinal.lift.{max u v, u} (Ordinal.typein r a) := by
  symm
  apply Quotient.sound
  constructor
  refine RelIso.ofSurjective ⟨⟨λ x ↦ ⟨f x.down, ?_⟩, ?_⟩, ?_⟩ ?_
  · simp only [f.map_rel_iff]
    exact x.down.prop
  · intro x y h
    apply ULift.down_injective
    apply Subtype.coe_injective
    simp only [ULift.up_inj, Subtype.mk.injEq,
      EmbeddingLike.apply_eq_iff_eq] at h
    exact h
  · intro x y
    simp only [Order.Preimage, Function.Embedding.coeFn_mk, subrel_val]
    exact f.map_rel_iff
  · intro x
    obtain ⟨y, hy⟩ := f.mem_range_of_rel x.down.prop
    refine ⟨ULift.up ⟨y, ?_⟩, ?_⟩
    · have := x.down.prop
      rwa [← hy, f.map_rel_iff] at this
    · apply ULift.down_injective
      apply Subtype.coe_injective
      simp only [RelEmbedding.coe_mk, Function.Embedding.coeFn_mk]
      exact hy

/-!
## The additive structure on the set of ordinals below a cardinal
-/

theorem card_Iio (o : Ordinal.{u}) : #(Set.Iio o) = Cardinal.lift.{u + 1} o.card := by
  rw [Cardinal.eq.mpr ⟨ToType.mk.toEquiv.trans Equiv.ulift.{u + 1, u}.symm⟩,
    mk_uLift, mk_toType, lift_card]

theorem type_Iio (o : Ordinal.{u}) :
    type ((· < ·) : Set.Iio o → Set.Iio o → Prop) = lift.{u + 1} o := by
  have := Ordinal.lift_type_eq.{u + 1, u, u + 1}
    (r := ((· < ·) : Set.Iio o → Set.Iio o → Prop))
    (s := ((· < ·) : o.ToType → o.ToType → Prop))
  rw [lift_id, type_toType] at this
  rw [this]
  exact ⟨ToType.mk.toRelIsoLT⟩

@[simp]
theorem typein_Iio {o : Ordinal.{u}} (x : Set.Iio o) :
    typein ((· < ·) : Set.Iio o → Set.Iio o → Prop) x = lift.{u + 1} x := by
  have := lift_typein_apply
      (r := ((· < ·) : Set.Iio o → Set.Iio o → Prop))
      (s := ((· < ·) : Ordinal → Ordinal → Prop))
      (f := ⟨⟨⟨Subtype.val, Subtype.val_injective⟩, ?_⟩, ?_⟩) x
  · rw [lift_id, lift_id, typein_ordinal] at this
    exact this.symm
  · rfl
  · simp only [RelEmbedding.coe_mk, Function.Embedding.coeFn_mk, Subtype.range_coe_subtype,
      Set.mem_Iio, Set.mem_setOf_eq, Subtype.forall]
    intro a ha b hb
    exact hb.trans ha

variable {c : Cardinal.{u}} (h : ℵ₀ ≤ c)

theorem add_lt_ord (h : ℵ₀ ≤ c) {x y : Ordinal.{u}}
    (hx : x < c.ord) (hy : y < c.ord) : x + y < c.ord := by
  rw [lt_ord] at hx hy ⊢
  rw [card_add]
  exact Cardinal.add_lt_of_lt h hx hy

def iioAdd : Add (Set.Iio c.ord) where
  add x y := ⟨x + y, add_lt_ord h x.prop y.prop⟩

def iioSub (o : Ordinal) : Sub (Set.Iio o) where
  sub x y := ⟨x - y, (sub_le_self x y).trans_lt x.prop⟩

theorem ord_pos (h : ℵ₀ ≤ c) : 0 < c.ord := by
  rw [lt_ord, card_zero]
  exact aleph0_pos.trans_le h

def iioZero : Zero (Set.Iio c.ord) where
  zero := ⟨0, ord_pos h⟩

@[simp]
theorem iioAdd_def (x y : Set.Iio c.ord) :
    letI := iioAdd h
    ((x + y : Set.Iio c.ord) : Ordinal) = x + y :=
  rfl

def iioAddMonoid : AddMonoid (Set.Iio c.ord) where
  add_assoc x y z := by
    apply Subtype.val_injective
    rw [iioAdd_def, iioAdd_def, add_assoc]
    rfl
  zero_add x := by
    apply Subtype.val_injective
    rw [iioAdd_def]
    exact zero_add x.val
  add_zero x := by
    apply Subtype.val_injective
    rw [iioAdd_def]
    exact add_zero x.val
  nsmul := nsmulRec
  __ := iioAdd h
  __ := iioZero h

theorem nat_lt_ord (h : ℵ₀ ≤ c) (n : ℕ) : n < c.ord := by
  apply (nat_lt_omega0 n).trans_le
  apply ord_mono at h
  rwa [ord_aleph0] at h

def iioOfNat (n : ℕ) : OfNat (Set.Iio c.ord) n where
  ofNat := ⟨n, nat_lt_ord h n⟩

theorem iioOfNat_coe (n : ℕ) :
    letI := iioOfNat h
    ((OfNat.ofNat n : Set.Iio c.ord) : Ordinal) = n :=
  rfl

theorem iio_noMaxOrder (h : ℵ₀ ≤ c) : NoMaxOrder (Set.Iio c.ord) := by
  letI := iioAdd h
  letI := iioOfNat h
  constructor
  intro x
  use x + 1
  rw [← Subtype.coe_lt_coe, iioAdd_def, lt_add_iff_pos_right, iioOfNat_coe, Nat.cast_one]
  exact zero_lt_one

end Ordinal
