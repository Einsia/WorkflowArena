module
public import ConNF.Background.Cardinal
public import ConNF.Mathlib.Basic.Rel
public import ConNF.Mathlib.SetTheory.Cardinal.Order
public import ConNF.ModelData.Support
public import ConNF.ModelData.CoherentData


public noncomputable section

universe u

open Cardinal Ordinal

namespace ConNF

variable [Params.{u}] [Level] [CoherentData]

theorem card_tangle_le (β : TypeIndex) [LeLevel β] :
    #(Tangle β) ≤ #μ := by
  sorry

end ConNF
