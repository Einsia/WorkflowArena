import Mathlib
import Poncelet.Elliptic

open WeierstrassCurve.Affine

variable {K : Type*} [Field K]
variable (cf : Config K)

theorem f_add_smul_g [DecidableEq K] [CharZero K] (p : (elliptic cf).Point) (n : ℕ) :
    f cf (p + n • g cf) = (next cf)^[n] (f cf p) := by
  sorry

