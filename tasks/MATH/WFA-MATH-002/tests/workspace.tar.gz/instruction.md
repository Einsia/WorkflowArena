# Task: Measurable Livšic rigidity on the two-sided shift

You are given a Lean 4 project in `/testbed` (toolchain `leanprover/lean4:v4.30.0-rc2`; dependencies pinned in `lake-manifest.json`
and fetched by `lake`, not vendored). Parts of the project that lead to the result below have been removed.

## Goal

In `ErgodicTheory/Livsic/BiShiftMeasurableRigidity.lean`, replace the `sorry` with a complete proof of `ErgodicTheory.hasVanishingPeriodicSums_of_measurable_aeCoboundary_biShift`:

```lean
theorem hasVanishingPeriodicSums_of_measurable_aeCoboundary_biShift
    (hν : ∀ a : α₀, ν {a} ≠ 0)
    {C r : ℝ≥0} {φ u : BiShift α₀ → ℝ} (hφ : HolderWith C r φ) (hr : 0 < r)
    (hu : Measurable u) (hae : IsAeCoboundaryOf (bernZ ν) biShiftMap φ u) :
    HasVanishingPeriodicSums biShiftMap φ
```

Keep the statement exactly as given (same name, binders, hypotheses and conclusion) and keep the file's existing
context (imports you need may be added).

## Rules

- You may add new Lean files anywhere in the project's source directories and import them where needed.
- Do not modify `lean-toolchain`, `lake-manifest.json`, the lakefile, or existing declarations in other files.
- No `sorry`, `admit`, new `axiom`, `unsafe`, `implemented_by`/`extern`, or kernel-check-skipping options.
  Only `propext`, `Quot.sound`, `Classical.choice` may appear in `#print axioms ErgodicTheory.hasVanishingPeriodicSums_of_measurable_aeCoboundary_biShift`.
- Final grading rebuilds your files in a clean copy of this repository and checks the statement and axioms
  independently; self-reported results are not used.
- Mathematical reference: Livšic theorem; Katok–Hasselblatt, Introduction to the Modern Theory of Dynamical Systems, §19.2

## Checks you may run

```sh
lake build
lake env lean ErgodicTheory/Livsic/BiShiftMeasurableRigidity.lean
```
