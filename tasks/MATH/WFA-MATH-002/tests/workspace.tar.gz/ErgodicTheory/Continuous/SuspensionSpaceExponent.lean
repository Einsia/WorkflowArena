/-
Copyright (c) 2026 Marcel Morgenstern. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Marcel Morgenstern
-/
import ErgodicTheory.Continuous.SuspensionExponentDescent
import ErgodicTheory.Continuous.SuspensionSpace

/-!
# The representative-free flow Lyapunov exponent on the suspension quotient

This module defines the **flow Lyapunov exponent** as a genuine property of a point of the orbit
quotient `SuspensionSpace T hτ` (the mapping torus of `T` under the roof `τ`), and proves it is
well defined: the growth rate `lim (1/t) log ‖coverCocycle p t‖` of the cover cocycle does not
depend on which representative `(x, s)` of the orbit class `[x, s]` is used to compute it.

The cover cocycle of `ErgodicTheory.Continuous.SuspensionCoverFlow` is the *cover-level*
special-flow cocycle: the accumulated matrix `coverCocycle (x, s) t` lives on `X × ℝ`, before
passing to the
quotient. As recorded in `ErgodicTheory.Continuous.SuspensionGrowthDescent`, the **matrix** cover
cocycle does *not* descend to the quotient — re-basing along one orbit step post-multiplies it by
the fixed factor `cocycle A T n x`. What *does* descend is the **growth rate**: the fixed
multiplicative factor becomes a fixed additive `log` shift, washed out by the `1/t` Birkhoff
average. The limit-transfer mechanism is `coverCocycle_suspensionAct_tendsto_exponent` (Module 1,
`ErgodicTheory.Continuous.SuspensionExponentDescent`); this module packages it into a
representative-free predicate on `SuspensionSpace`.

This is the standard special-flow / flow-under-a-roof bookkeeping of Cornfeld–Fomin–Sinai,
*Ergodic Theory* (Springer 1982), Ch. 11 (special/suspension flows; Ambrose–Kakutani); the
descent direction — the *exponent*, not the matrix, passes to the quotient — is the design
reference of Bessa–Varandas (suspension Lyapunov exponents). The headline analogue is Abramov's
entropy formula `h(flow) = h(base)/∫τ` (L. M. Abramov, *On the entropy of a flow*, Dokl. Akad.
Nauk SSSR **128** (1959) 873–875).

## Main definitions

* `ErgodicTheory.HasFlowExponent`: the predicate `HasFlowExponent q L` on
  `q : SuspensionSpace T hτ`,
  asserting that **some** representative `(x, s)` of the orbit class `q` carries the cover-cocycle
  growth rate `L`, i.e. `suspensionMk (x, s) = q` and
  `Tendsto (fun t ↦ log ‖coverCocycle (x, s) t‖ / t) atTop (𝓝 L)`. The existential form lifts
  cleanly to the quotient; the well-definedness theorems below show the growth rate is in fact the
  same for *every* representative under invertibility.

## Main results

* `ErgodicTheory.tendsto_exponent_iff_of_suspensionAct`: the **two-sided well-definedness** for a
  forward orbit step. If `suspensionAct (n : ℤ) (x, s) = (x₂, s₂)` for a natural `n`, and the base
  cocycle is invertible with both cover-cocycle norms eventually strictly positive, then the
  cover-cocycle growth rates at `(x, s)` and at `(x₂, s₂)` converge to `L` for *the same* `L`: the
  two `Tendsto` statements are equivalent. The `→` direction is the Module-1 limit transfer; the
  `←` direction is its mirror, obtained from the *symmetric* additive `log`-discrepancy bound
  `coverCocycle_suspensionAct_log_discrepancy` by the same `1/t` squeeze.
* `ErgodicTheory.hasFlowExponent_of_suspensionAct`: orbit-class invariance of `HasFlowExponent`. If
  two cover points are connected by a forward orbit step `suspensionAct (n : ℤ) (x, s) = (x₂, s₂)`
  (so `suspensionMk (x, s) = suspensionMk (x₂, s₂)`) then, under the same hypotheses,
  `Tendsto (fun t ↦ log ‖coverCocycle (x, s) t‖ / t) atTop (𝓝 L)` *witnesses*
  `HasFlowExponent (suspensionMk (x₂, s₂)) L`: the growth rate computed at one representative
  certifies the exponent of the whole orbit class.

## The signed-step gap (now closed)

The two well-definedness results here are keyed on a **forward** orbit step `suspensionAct (n : ℤ)`
with `n : ℕ`. Orbit equivalence in `SuspensionSpace` — `suspensionMk (x, s) = suspensionMk
(x₂, s₂)` — unfolds (via `Quotient.eq` and `AddAction.mem_orbit_iff`) to a *signed* integer
`m : ℤ` with `suspensionAct m (x₂, s₂) = (x, s)`, so the descent needs the `m < 0` (backward-step)
case as well.

That signed-integer closure is now **fully discharged** in
`ErgodicTheory/Continuous/SuspensionFlowExponentQuotient.lean`:
`tendsto_exponent_iff_of_orbitRel` handles both signs (each reduces to the forward iff above at a
different base point), the descended `flowExponentAt` is the `Quotient.lift` of the
representative-level growth rate (a fixed-junk `dite`/`Exists.choose`, whose junk value — unlike
`limUnder` — is constant across representatives), and `ae_flowExponentAt_eq_base_div_roof` gives
the `μ̂`-a.e. identification `flowExponentAt q = λ_base / ∫τ` of the genuine `SuspensionSpace → ℝ`
function. The one honest cost of making the lift **total** is a global base-cocycle invertibility
hypothesis `∀ x, (A x).det ≠ 0`, which the descended function carries throughout. This module
still supplies only the forward-step well-definedness feeding that closure.
-/

open Filter Topology
open scoped Matrix.Norms.L2Operator

namespace ErgodicTheory

section SpaceExponent

variable {X : Type*} [MeasurableSpace X] {d : ℕ} (A : X → Matrix (Fin d) (Fin d) ℝ)
  (T : X ≃ᵐ X) {τ : X → ℝ} (hτ : Measurable τ) {c : ℝ}

/-- **The flow Lyapunov exponent of a point of the suspension quotient.** `HasFlowExponent q L`
holds when **some** representative `(x, s)` of the orbit class `q : SuspensionSpace T hτ` carries
the cover-cocycle growth rate `L`:
`suspensionMk (x, s) = q ∧ Tendsto (fun t ↦ log ‖coverCocycle (x, s) t‖ / t) atTop (𝓝 L)`.

The existential form is what lifts cleanly to the quotient (a property of *some* representative);
the well-definedness theorems `tendsto_exponent_iff_of_suspensionAct` /
`hasFlowExponent_of_suspensionAct` show that, under base-cocycle invertibility, the growth rate is
the *same* for every representative — so `HasFlowExponent q L` is a genuine property of the orbit
class `q`. -/
def HasFlowExponent (hc : ∀ x, c ≤ τ x) (hcpos : 0 < c) (q : SuspensionSpace T hτ) (L : ℝ) :
    Prop :=
  ∃ x : X, ∃ s : ℝ, suspensionMk T hτ (x, s) = q ∧
    Tendsto (fun t : ℝ => Real.log ‖coverCocycle A T hτ hc hcpos (x, s) t‖ / t) atTop (𝓝 L)

set_option maxHeartbeats 400000 in -- the `←` mirror threads the symmetric squeeze over the long
-- `coverCocycle` terms exactly as Module 1's forward transfer does; the default budget is exceeded
/-- **Two-sided well-definedness across a forward orbit step.** If the cover point `(x₂, s₂)` is the
forward orbit image `suspensionAct (n : ℤ) (x, s)` for a natural `n`, the base cocycle is
invertible, and both cover-cocycle norms are eventually strictly positive, then the cover-cocycle
growth rates at `(x, s)` and at `(x₂, s₂)` converge to one and the *same* `L`:
`Tendsto (fun t ↦ log ‖coverCocycle (x, s) t‖ / t) atTop (𝓝 L)`
  `↔ Tendsto (fun t ↦ log ‖coverCocycle (x₂, s₂) t‖ / t) atTop (𝓝 L)`.

The `→` direction is the Module-1 limit transfer `coverCocycle_suspensionAct_tendsto_exponent`. The
`←` direction is its mirror: the additive `log`-discrepancy bound
`coverCocycle_suspensionAct_log_discrepancy` is *symmetric* in the two points, so the per-`t`
average at `(x, s)` lies within `C / t` of the average at the re-based point, and the same
`Filter.Tendsto` squeeze transfers the limit the other way. -/
theorem tendsto_exponent_iff_of_suspensionAct [NeZero d] (hc : ∀ x, c ≤ τ x) (hcpos : 0 < c)
    (n : ℕ) (x : X) (s : ℝ) (hU : IsUnit (cocycle A (⇑T) n x).det)
    (hret : ∀ᶠ t : ℝ in atTop, returnTime T hτ n x ≤ s + t)
    (hp : ∀ᶠ t : ℝ in atTop, 0 < ‖coverCocycle A T hτ hc hcpos (x, s) t‖)
    (hq : ∀ᶠ t : ℝ in atTop,
        0 < ‖coverCocycle A T hτ hc hcpos (suspensionAct T hτ (n : ℤ) (x, s)) t‖)
    {L : ℝ} :
    Tendsto (fun t : ℝ => Real.log ‖coverCocycle A T hτ hc hcpos (x, s) t‖ / t) atTop (𝓝 L)
      ↔ Tendsto (fun t : ℝ =>
          Real.log ‖coverCocycle A T hτ hc hcpos (suspensionAct T hτ (n : ℤ) (x, s)) t‖ / t)
        atTop (𝓝 L) := by
  set C : ℝ := |Real.log ‖cocycle A (⇑T) n x‖| + |Real.log ‖(cocycle A (⇑T) n x)⁻¹‖| with hCdef
  set P : ℝ → ℝ := fun t => Real.log ‖coverCocycle A T hτ hc hcpos (x, s) t‖ with hPdef
  set Q : ℝ → ℝ := fun t =>
    Real.log ‖coverCocycle A T hτ hc hcpos (suspensionAct T hτ (n : ℤ) (x, s)) t‖ with hQdef
  constructor
  · -- Forward: this is exactly the Module-1 limit transfer.
    intro hL
    exact coverCocycle_suspensionAct_tendsto_exponent A T hτ hc hcpos n x s hU hret hp hq hL
  · -- Backward: the mirror squeeze, using the symmetry of the additive `log`-discrepancy bound.
    intro hL
    have hConst : Tendsto (fun t : ℝ => C / t) atTop (𝓝 0) :=
      Tendsto.div_atTop tendsto_const_nhds tendsto_id
    have hLo : Tendsto (fun t : ℝ => Q t / t - C / t) atTop (𝓝 L) := by
      have := hL.sub hConst; simpa using this
    have hUp : Tendsto (fun t : ℝ => Q t / t + C / t) atTop (𝓝 L) := by
      have := hL.add hConst; simpa using this
    have hsand : ∀ᶠ t : ℝ in atTop,
        Q t / t - C / t ≤ P t / t ∧ P t / t ≤ Q t / t + C / t := by
      filter_upwards [hret, hp, hq, eventually_gt_atTop (0 : ℝ)]
        with t htret htp htq htpos
      have hdisc := coverCocycle_suspensionAct_log_discrepancy
        A T hτ hc hcpos n x s t htret hU htp htq
      rw [abs_le] at hdisc
      obtain ⟨hd1, hd2⟩ := hdisc
      -- `hd1 : -C ≤ Q t - P t`, `hd2 : Q t - P t ≤ C`.
      have hinv : 0 < t⁻¹ := inv_pos.2 htpos
      refine ⟨?_, ?_⟩
      · have : (Q t - C) * t⁻¹ ≤ P t * t⁻¹ :=
          mul_le_mul_of_nonneg_right (by linarith [hd2]) (le_of_lt hinv)
        rw [sub_mul] at this
        simpa only [div_eq_mul_inv] using this
      · have : P t * t⁻¹ ≤ (Q t + C) * t⁻¹ :=
          mul_le_mul_of_nonneg_right (by linarith [hd1]) (le_of_lt hinv)
        rw [add_mul] at this
        simpa only [div_eq_mul_inv] using this
    have hlow : ∀ᶠ t : ℝ in atTop, Q t / t - C / t ≤ P t / t := hsand.mono fun _ h => h.1
    have hupp : ∀ᶠ t : ℝ in atTop, P t / t ≤ Q t / t + C / t := hsand.mono fun _ h => h.2
    exact tendsto_of_tendsto_of_tendsto_of_le_of_le' hLo hUp hlow hupp

/-- **Orbit-class invariance of the flow exponent.** If two cover points are connected by a forward
orbit step `suspensionAct (n : ℤ) (x, s) = (x₂, s₂)` (so `suspensionMk (x, s) = suspensionMk
(x₂, s₂)`), then the growth rate `L` computed at the representative `(x, s)` certifies the
flow exponent of the orbit class of `(x₂, s₂)`: it produces a `HasFlowExponent (suspensionMk
(x₂, s₂)) L` witness. This is the well-definedness of the flow exponent under (forward) orbit
equivalence: the exponent is a property of the class, read off from any representative.

The orbit step `hxs` is used to identify the two orbit classes (`suspensionMk` of orbit-equivalent
points agree); the growth rate at `(x, s)` then directly witnesses the exponent of the common
class. (No invertibility — nor even `NeZero d` — is needed for *this* direction: `(x, s)` itself
serves as the witness; invertibility enters only in `tendsto_exponent_iff_of_suspensionAct`, which
guarantees the *same* `L` is obtained from the *other* representative `(x₂, s₂)`.) -/
theorem hasFlowExponent_of_suspensionAct (hc : ∀ x, c ≤ τ x) (hcpos : 0 < c)
    (n : ℕ) (x : X) (s : ℝ) {x₂ : X} {s₂ : ℝ}
    (hxs : suspensionAct T hτ (n : ℤ) (x, s) = (x₂, s₂))
    {L : ℝ}
    (hL : Tendsto (fun t : ℝ => Real.log ‖coverCocycle A T hτ hc hcpos (x, s) t‖ / t)
        atTop (𝓝 L)) :
    HasFlowExponent A T hτ hc hcpos (suspensionMk T hτ (x₂, s₂)) L := by
  -- The two orbit classes coincide: `(x, s)` and `(x₂, s₂) = suspensionAct n (x, s)` are
  -- orbit-equivalent, so `suspensionMk` sends them to the same point of `SuspensionSpace`.
  have hmk : suspensionMk T hτ (x, s) = suspensionMk T hτ (x₂, s₂) := by
    letI := suspensionAddAction T hτ
    apply Quotient.sound
    -- `(x, s) ≈ (x₂, s₂)` for `orbitRel` means `(x, s) ∈ orbit ℤ (x₂, s₂)`, witnessed by `-n`.
    change (x, s) ∈ AddAction.orbit ℤ (x₂, s₂)
    rw [AddAction.mem_orbit_iff]
    refine ⟨-(n : ℤ), ?_⟩
    change suspensionAct T hτ (-(n : ℤ)) (x₂, s₂) = (x, s)
    rw [← hxs, ← suspensionAct_add, neg_add_cancel, suspensionAct_zero]
  -- The witness representative is `(x, s)`; its growth rate is `L` by the forward limit transfer.
  refine ⟨x, s, hmk, ?_⟩
  exact hL

end SpaceExponent

end ErgodicTheory
