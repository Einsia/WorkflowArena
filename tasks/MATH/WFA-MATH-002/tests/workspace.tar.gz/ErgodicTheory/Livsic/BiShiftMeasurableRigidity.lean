/-
Copyright (c) 2026 Marcel Morgenstern. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Marcel Morgenstern
-/
import ErgodicTheory.Livsic.BiShiftMetric
import ErgodicTheory.Livsic.Defs
import ErgodicTheory.Livsic.ShiftMetric
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import ErgodicTheory.Livsic.DenseOrbit
import ErgodicTheory.Livsic.Abstract
import ErgodicTheory.Livsic.ContinuousRigidity
import ErgodicTheory.Livsic.BoundedRigidity
import ErgodicTheory.Multifractal.BernoulliTwoSided
import Mathlib.MeasureTheory.Measure.Prod
import Mathlib.MeasureTheory.Function.ContinuousMapDense
import Mathlib.MeasureTheory.Function.ConvergenceInMeasure
import Mathlib.MeasureTheory.Function.Egorov
import Mathlib.MeasureTheory.Measure.Regular
import Mathlib.MeasureTheory.Measure.RegularityCompacts
import Mathlib.MeasureTheory.Constructions.Polish.Basic
import Mathlib.MeasureTheory.Function.SpecialFunctions.Arctan
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Arctan
import Mathlib.Topology.UniformSpace.UniformApproximation

/-!
# Measurable Livšic rigidity on the two-sided shift
-/

open MeasureTheory Filter Set Function
open scoped ENNReal NNReal

namespace ErgodicTheory

open ErgodicTheory.Multifractal ErgodicTheory.Livsic

section Glue

end Glue

section BiShift

attribute [local instance] biShiftMetricSpace

variable {α₀ : Type*} [Finite α₀] [TopologicalSpace α₀] [DiscreteTopology α₀]
  [MeasurableSpace α₀] [MeasurableSingletonClass α₀]
variable (ν : Measure α₀) [IsProbabilityMeasure ν]

/-- Documentation omitted. -/
theorem hasVanishingPeriodicSums_of_measurable_aeCoboundary_biShift
    (hν : ∀ a : α₀, ν {a} ≠ 0)
    {C r : ℝ≥0} {φ u : BiShift α₀ → ℝ} (hφ : HolderWith C r φ) (hr : 0 < r)
    (hu : Measurable u) (hae : IsAeCoboundaryOf (bernZ ν) biShiftMap φ u) :
    HasVanishingPeriodicSums biShiftMap φ := by
  sorry

end BiShift

end ErgodicTheory
