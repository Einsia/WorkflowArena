/-
Copyright (c) 2026 Marcel Morgenstern. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Marcel Morgenstern
-/
import ErgodicTheory.Livsic.Defs
import Mathlib.MeasureTheory.Measure.OpenPos

/-!
# Livšic rigidity for continuous transfer functions
-/

open MeasureTheory Filter Function
open scoped Topology

namespace ErgodicTheory

variable {X : Type*} [MeasurableSpace X]

/-- **Witnessed a.e. coboundary.** `φ` equals `u ∘ T − u` on a set of full `μ`-measure. Fully
generic (no dynamical hypotheses), the a.e. analogue of `IsCoboundary`. -/
def IsAeCoboundaryOf (μ : Measure X) (T : X → X) (φ u : X → ℝ) : Prop :=
  φ =ᵐ[μ] fun x => u (T x) - u x

/-- **Measurable a.e. coboundary.** `φ` is the a.e. coboundary of *some* measurable transfer
function `u`. This is the hypothesis of the measurable-Livšic rigidity theorem. -/
def IsAeCoboundary (μ : Measure X) (T : X → X) (φ : X → ℝ) : Prop :=
  ∃ u : X → ℝ, Measurable u ∧ IsAeCoboundaryOf μ T φ u

namespace Livsic

/-! ### Continuous-tier Livšic rigidity -/

variable [TopologicalSpace X] {μ : Measure X} [μ.IsOpenPosMeasure]

/-- **Continuous-tier Livšic rigidity.** If `φ` is continuous and equals the coboundary of a
**continuous** `u` only `μ`-a.e., then — because `μ` is fully supported, so a.e.-equal continuous
functions are equal — `φ` is an *everywhere* coboundary, hence (via the trivial telescoping
direction `IsCoboundary.hasVanishingPeriodicSums`) has vanishing periodic sums.

This is the rigidity theorem in the regularity class in which it is elementary. The substantive
content of measurable Livšic is precisely the *promotion of a merely measurable `u` to a continuous
one*; once that promotion is available, this lemma finishes. -/
theorem hasVanishingPeriodicSums_of_continuous_coboundary {T : X → X} {φ u : X → ℝ}
    (hT : Continuous T) (hu : Continuous u) (hφ : Continuous φ)
    (hcob : IsAeCoboundaryOf μ T φ u) :
    HasVanishingPeriodicSums T φ := by
  -- Upgrade the a.e. equation to a pointwise (everywhere) equation, then use the trivial direction.
  have hpt : ∀ x, φ x = u (T x) - u x :=
    fun x => congrFun ((Continuous.ae_eq_iff_eq μ hφ ((hu.comp hT).sub hu)).1 hcob) x
  exact IsCoboundary.hasVanishingPeriodicSums ⟨u, hpt⟩

end Livsic

end ErgodicTheory
