module

public import Mathlib.Data.Set.Card
public import Mathlib.Algebra.Group.Pointwise.Finset.BigOperators
public import PFR.Main
public import Mathlib.Algebra.BigOperators.Group.Multiset.Defs
public import Mathlib.Algebra.BigOperators.Fin
public import Mathlib.Data.Fin.Basic
public import Mathlib.MeasureTheory.Group.Arithmetic
public import Mathlib.Order.Interval.Finset.Defs
public import Mathlib.Order.Interval.Finset.Fin
public import PFR.ForMathlib.Entropy.RuzsaDist
public import PFR.HundredPercent
public import Mathlib.MeasureTheory.Measure.FiniteMeasurePi
public import Mathlib.MeasureTheory.Measure.Prokhorov

public section

open MeasureTheory ProbabilityTheory Set
open scoped Pointwise

section AnalyzeMinimizer

universe u

end AnalyzeMinimizer

universe u
open Real

/-- Suppose that $G$ is an abelian group of torsion $m$ (not necessarily finite).
If $A \subset G$ is a finite non-empty set with $|A+A| \leq K|A|$, then $A$ can be covered by at
most $m K^{256 m^3+1}$ translates of a finite subspace $H$ of $G$ with $|H| \leq |A|$. -/
theorem torsion_PFR {G : Type*} [AddCommGroup G] {m : ℕ} (hm : m ≥ 2)
    (htorsion : ∀ x : G, m • x = 0) {A : Set G} (Afin : A.Finite) {K : ℝ} (h₀A : A.Nonempty)
    (hA : Nat.card (A + A) ≤ K * A.ncard) :
    ∃ (H : AddSubgroup G) (c : Set G), c.Finite ∧ (H : Set G).Finite ∧
      Nat.card c < m * K ^ (256 * m ^ 3 + 1) ∧ (H : Set G).ncard ≤ A.ncard ∧ A ⊆ c + H := by
  sorry

