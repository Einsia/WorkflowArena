module

public import PFR.Main
public import PFR.Mathlib.Probability.Independence.Basic
public import PFR.ForMathlib.Pair
public import Mathlib.Probability.IdentDistrib
public import PFR.ForMathlib.Entropy.Basic
public import PFR.ForMathlib.FiniteRange.Defs
public import PFR.Mathlib.MeasureTheory.Measure.ProbabilityMeasure
public import Mathlib.Algebra.BigOperators.Field
public import Mathlib.Analysis.Convex.Jensen
public import Mathlib.Analysis.SpecialFunctions.Log.NegMulLog

@[expose] public section

open MeasureTheory ProbabilityTheory Real Set Function Measure Filter
open scoped Pointwise ENNReal Topology
universe uG

section

end

section phiMinimizer

open Filter
open scoped Topology

end phiMinimizer

section PFR

/-- If $A \subset {\bf F}_2^n$ is finite non-empty with $|A+A| \leq K|A|$, then there exists a
subgroup $H$ of ${\bf F}_2^n$ with $|H| \leq |A|$ such that $A$ can be covered by at most $2K^9$
translates of $H$.

The ambient group need not be finite, in which case `H` and `c` are finite. -/
theorem better_PFR_conjecture {G : Type*} [AddCommGroup G] [Module (ZMod 2) G]
    {A : Set G} {K : ℝ} (h₀A : A.Nonempty) (Afin : A.Finite)
    (hA : Nat.card (A + A) ≤ K * Nat.card A) :
    ∃ (H : Submodule (ZMod 2) G) (c : Set G), c.Finite ∧ (H : Set G).Finite ∧
      Nat.card c < 2 * K ^ 9 ∧ (H : Set G).ncard ≤ Nat.card A ∧ A ⊆ c + H := by
  sorry

end PFR
