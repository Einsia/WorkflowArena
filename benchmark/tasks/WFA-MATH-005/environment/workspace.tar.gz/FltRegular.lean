module
import FltRegular.NumberTheory.Cyclotomic.Rat
import FltRegular.SmallNumbers.SmallNumbers

/-!
# Fermat's Last Theorem for regular primes

This is the root import module for the `FltRegular` library.
-/
