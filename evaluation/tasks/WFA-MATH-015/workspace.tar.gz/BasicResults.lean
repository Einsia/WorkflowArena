/-
Copyright (c) 2026 Mario Ullrich. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Ullrich
-/
module

public import BasicResults.Auerbach
public import BasicResults.SVD
public import BasicResults.LittleGrothendieck
public import BasicResults.John
public import BasicResults.Spectral.MonotoneConvergence
public import BasicResults.Spectral.Complexification
public import BasicResults.Spectral.Projection
public import BasicResults.Spectral.RealProjection
public import BasicResults.Spectral.Representation
public import BasicResults.Spectral.MultiplicationOperator

/-!
# Basic results
-/
