module

public import Mathlib.Combinatorics.Additive.PluenneckeRuzsa
public import Mathlib.GroupTheory.Coset.Card
public import Mathlib.LinearAlgebra.Dimension.FreeAndStrongRankCondition
public import Mathlib.LinearAlgebra.FreeModule.ModN
public import Mathlib.LinearAlgebra.FreeModule.PID
public import Mathlib.MeasureTheory.Constructions.SubmoduleQuotient
public import PFR.ForMathlib.AffineSpaceDim
public import PFR.ForMathlib.Entropy.RuzsaDist
public import PFR.Main
public import Mathlib.Algebra.Group.Action.Pointwise.Set.Basic
public import Mathlib.LinearAlgebra.Quotient.Basic

@[expose] public section

open Set
open scoped Pointwise
section AddCommGroup
end AddCommGroup

section Torsion

open Real ProbabilityTheory MeasureTheory

end Torsion

section F2_projection

open Real ProbabilityTheory MeasureTheory

end F2_projection

open MeasureTheory ProbabilityTheory Real Set

open Real MeasureTheory ProbabilityTheory Pointwise Set Function
open QuotientAddGroup

attribute [local norm_cast] Nat.card_coe_set_eq Set.ncard_coe_finset

/-- Documentation omitted. -/
theorem weak_PFR_int_sumset
    {G : Type*} [AddCommGroup G] [Module.Free ℤ G] [Module.Finite ℤ G]
    {A : Set G} (hA : A.Finite) (hnA : A.Nonempty) {K : ℝ}
    (hAK : Nat.card (A + A) ≤ K * Nat.card A) :
    ∃ A' ⊆ A, Nat.card A' ≥ K ^ (-34 : ℝ) * Nat.card A ∧
      AffineSpace.finrank ℤ A' ≤ (80 / log 2) * log K := by
  sorry

